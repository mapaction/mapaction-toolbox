#Test ConfigParser

#from ConfigParser import *
import ConfigParser, sys
configdict = ConfigParser.ConfigParser()
#configdict = ConfigParser()
print sys.path[0]
configdict.read(sys.path[0]+'\\Cookie_Cutter2.inf')
print configdict.items('DEFAULT')
#print configdict.defaults()['project_directory']
#project_directory = configdict.defaults()[r'project_directory']
#nextmap_dsm_img = configdict.defaults()[r'dem']
#gp.cellSize = configdict.defaults()['cell_size']
#tension_parameter = configdict.defaults()['tension_parameter']
#buffer_parameter = configdict.defaults()['buffer_parameter']

#print tension_parameter 

